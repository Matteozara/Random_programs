<!DOCTYPE html>
<html>
    
    <head class="col">
        <div class="titolo">
            <h3>RistoClick</h3>
        </div>
        

    </head>
    <body>

        <style>
            .titolo
            {
                align-items: left;
                width: 350px;
                height: 100px;
            }

            body
            {
                background-color:aliceblue;
                font-size: large;
                font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            }
            
            .column1
            {
                color:black;
                font: size 30;
                width: 300px;
                margin-right: 10px;
                float: left;
                margin-top: 0px;
                font-size: 20px;
            }
            h3
            {
                font-family:cursive;
                font-size: 40px;
                color:yellow;
                text-align: center;
                border-style: solid;
                border-radius: 50%;
                border-color: black;
                border-width: 5px;
            }
            h4
            {   
                margin-top: 0px;
                margin-bottom: 5px;
                font-family: fantasy;
                font-size: large;
                font-style: italic;
                font-size: 30px;
            }
            
            .testo
            {
                margin-right: 50px;
                margin-left: 400px;
                margin-top: 40px;
                text-align: justify;
                
            }
                
        </style>


    <hr>
    <div class="column1">
        
        <br>
        <a href="Cliente.php">Cliente</a>
        <ul>
            <li>
                <a href="Prenotazione.php">Prenotazione</a>
            </li>  
            <li>
                <a href="Recensione.php">Recesione</a>
            </li>
        </ul>
        <br>
        <a href="Ristoratore.php">Ristoratore</a>
        <ul>
            <li>
                <a href="Registrazione.php">Registrati</a>
            </li>
            <li>
                <a href="Approvigionamenti.php">Regista approvigionamenti</a>
            </li>
            <li>
                <a href="Magazzini.php">Nuovo magazzino</a>
            </li>
            <li>
                <a href="Personale.php">Aggiungi personale</a>
            </li>
            <li>
                <a href="Rifornitori.php">Aggiungi rifornitore</a>
            </li>
        </ul>
       
    </div>

    <p>
        <div class="testo">
        <h4>Personale</h4>
        <br>
        In questa pagina è possibile inserire i dati di nuovi membri del personale, per farlo basta inserire i 
        loro dati (uno alla volta) qui sotto.
        <br>
        <br>
        Inserisca i dati di un dipendente o titolare:
        <br>
        <br>
        <form action="Personale.php" method="POST">
        Nome: <input type="text" name="nome">
        <br>
        Cognome: <input type="text" name="cognome">
        <br>
        Codice Fiscale: <input type="text" name="cf">
        <br>
        Ruolo: <input type="text" name="ruolo">  &nbsp;&nbsp;&nbsp;  relativa descrizione: <input type="text" name="descriz">
        <br>
        Nome del Ristorante in cui lavora: <input type="text" name="nomeR">
        <br>
        <br>
        <input type="submit" value="Inserisci" name="submit">
        </form>

        <br>
        <br>
        <br>
        Per ritornare all'<a href="Ristorante.php">home page</a>

        </div>
    </p>

    <?php
    //error_reporting(0);

    function Successo()
		{
			echo '<script>
			alert("I dati sono stati inseriti correttamente!")
			</script>';
		}
    
        function Errore()
		{
			echo '<script>
			alert("Errore, i valori inseriti non sono corretti o non sono comleti! Riprova")
			</script>';
		}
        
    $host = "localhost";
    $database = "ristorante";
    $user = "postgres";
    $password = "12345Ciao6789";

    $connection = pg_connect("host=$host dbname=$database user=$user password=$password") 
        or die(pg_last_error());
	
	$nome = $_POST['nome'];
	$cognome = $_POST['cognome'];
    $cf = $_POST['cf'];
    $ruolo = $_POST['ruolo'];
    $descriz = $_POST['descriz'];
    $nomeR = $_POST['nomeR'];
    
    if ((strlen($nome) == 0 || strlen($cognome) == 0 || strlen($cf) == 0 || strlen($nomeR) == 0 || strlen($ruolo) == 0) && (strlen($nome) != 0 || strlen($cognome) != 0 || strlen($cf) != 0 || strlen($nomeR) != 0 || strlen($ruolo) != 0))
        Errore();
	if(strlen($nome) != 0 && strlen($cognome) != 0 && strlen($cf) != 0 && strlen($nomeR) != 0 && strlen($ruolo) != 0)
    {	$query1 = "INSERT INTO mansione (ruolo, descrizione) VALUES ('$ruolo', '$descriz');";
        $query2 = "INSERT INTO personale (cf, nome, cognome, ruolo, nomer) VALUES ('$cf', '$nome', '$cognome', '$ruolo', '$nomeR');";
        
        
    	$result1 = pg_query($connection, $query1)
        or die();//"Encountered an error when executing given sql statement: ". pg_last_error(). "<br/>");
        $result2 = pg_query($connection, $query2)
        or die();
        if ($result1 != false && $result2 != false)
            Successo();
    }
    ?>

        
       
    </body>
</html>