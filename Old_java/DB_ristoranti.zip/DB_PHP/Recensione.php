<!DOCTYPE html>
<html>
    
    <head class="col">
        <div class="titolo">
            <h3>RistoClick</h3>
        </div>
        

    </head>
    <body>

        <style>
            .titolo
            {
                align-items: left;
                width: 350px;
                height: 100px;
            }

            body
            {
                background-color:aliceblue;
                font-size: large;
                font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            }
            
            .column1
            {
                color:black;
                font: size 30;
                width: 300px;
                margin-right: 10px;
                float: left;
                margin-top: 0px;
                font-size: 20px;
            }
            h3
            {
                font-family:cursive;
                font-size: 40px;
                color:yellow;
                text-align: center;
                border-style: solid;
                border-radius: 50%;
                border-color: black;
                border-width: 5px;
            }
            h4
            {   
                margin-top: 0px;
                margin-bottom: 5px;
                font-family: fantasy;
                font-size: large;
                font-style: italic;
                font-size: 30px;
            }
            
            .testo
            {
                margin-right: 50px;
                margin-left: 400px;
                margin-top: 40px;
                text-align: justify;
                
            }
                
        </style>


    <hr>
    <div class="column1">
        
        <br>
        <a href="Cliente.php">Cliente</a>
        <ul>
            <li>
                <a href="Prenotazione.php">Prenotazione</a>
            </li>  
            <li>
                <a href="Recensione.php">Recesione</a>
            </li>
        </ul>
        <br>
        <a href="Ristoratore.php">Ristoratore</a>
        <ul>
            <li>
                <a href="Registrazione.php">Registrati</a>
            </li>
            <li>
                <a href="Approvigionamenti.php">Regista approvigionamenti</a>
            </li>
            <li>
                <a href="Magazzini.php">Nuovo magazzino</a>
            </li>
            <li>
                <a href="Personale.php">Aggiungi personale</a>
            </li>
            <li>
                <a href="Rifornitori.php">Aggiungi rifornitore</a>
            </li>
        </ul>
       
    </div>

    <p>
        <div class="testo">
        <h4>Recensioni</h4>
        <br>
        Per effettuare una recensione basta compilare i campi sottostanti:
        <br>
        <br>
        <form action="Recensione.php" method="POST">
        Il suo nome: <input type="text" name="nome">
        <br>
        Numero di telefono: <input type="text" name="numero">     <small>  *solo per riconoscerla univocamente nel database </small> 
        <br>
        Nome del ristorante: <input type="text" name="nomeR">
        <br>
        Numero di stelle: <input type="number" name="stelle"> <small>     *inserisca un numero da 0 a 5</small>
        <br>
        Descrizione: 
        <br>
        <textarea rows="3" cols="40" name="descrizione"></textarea>
        <br>
        <br>
        <input type="submit" value="Invia" name="submit">
        </form>
        <br>
        <br>
        <br>
        Per ritornare all'<a href="Ristorante.php">home page</a>
        </div>

    <?php
    //error_reporting(0);

    function Successo()
		{
			echo '<script>
			alert("I dati sono stati inseriti correttamente!")
			</script>';
		}
    
        function Errore()
		{
			echo '<script>
			alert("Errore, i valori inseriti non sono corretti o non sono comleti! Riprova")
			</script>';
		}

    $host = "localhost";
    $database = "ristorante";
    $user = "postgres";
    $password = "12345Ciao6789";

    $connection = pg_connect("host=$host dbname=$database user=$user password=$password") 
        or die(pg_last_error());
	
	$nome = $_POST['nome'];
	$numero = $_POST['numero'];
    $nomeR = $_POST['nomeR'];
    $stelle = $_POST['stelle'];
    $descriz = $_POST['descrizione'];
    
    if ((strlen($nomeR) == 0 || strlen($nome) == 0 || strlen($numero) == 0) && (strlen($nomeR) != 0 || strlen($nome) != 0 || strlen($numero) != 0))
        Errore();
	if(strlen($nomeR) != 0 && strlen($nome) != 0 && strlen($numero) != 0)
    {	$query1 = "INSERT INTO recensione (testo, n_stelle, nomer, nomec, n_telefono) VALUES ('$descriz', $stelle, '$nomeR', '$nome', '$numero');";
        
    	$result1 = pg_query($connection, $query1)
        or die();//"Encountered an error when executing given sql statement: ". pg_last_error(). "<br/>");
        if ($result1 != false)
            Successo();
    }
    ?>

    </p>

    
    </body>
</html>