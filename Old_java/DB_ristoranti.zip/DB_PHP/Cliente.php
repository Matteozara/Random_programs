<!DOCTYPE html>
<html>

    <head class="col">
        <div class="titolo">
            <h3>RistoClick</h3>
        </div>
        

    </head>
    <body>

        <style>
            .titolo
            {
                align-items: left;
                width: 350px;
                height: 100px;
            }

            body
            {
                background-color:aliceblue;
                font-size: large;
                font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            }
            
            .column1
            {
                color:black;
                font: size 30;
                width: 300px;
                margin-right: 10px;
                float: left;
                margin-top: 0px;
                font-size: 20px;
            }
            h3
            {
                font-family:cursive;
                font-size: 40px;
                color:yellow;
                text-align: center;
                border-style: solid;
                border-radius: 50%;
                border-color: black;
                border-width: 5px;
            }
            h4
            {   
                margin-top: 0px;
                margin-bottom: 5px;
                font-family: fantasy;
                font-size: large;
                font-style: italic;
                font-size: 30px;
            }
            
            .testo
            {
                margin-right: 50px;
                margin-left: 400px;
                margin-top: 40px;
                text-align: justify;
                
            }
                
        </style>


    <hr>
    <div class="column1">
        
        <br>
        <a href="Cliente.php">Cliente</a>
        <ul>
            <li>
                <a href="Prenotazione.php">Prenotazione</a>
            </li>  
            <li>
                <a href="Recensione.php">Recesione</a>
            </li>
        </ul>
        <br>
        <a href="Ristoratore.php">Ristoratore</a>
        <ul>
            <li>
                <a href="Registrazione.php">Registrati</a>
            </li>
            <li>
                <a href="Approvigionamenti.php">Regista approvigionamenti</a>
            </li>
            <li>
                <a href="Magazzini.php">Nuovo magazzino</a>
            </li>
            <li>
                <a href="Personale.php">Aggiungi personale</a>
            </li>
            <li>
                <a href="Rifornitori.php">Aggiungi rifornitore</a>
            </li>
        </ul>
       
    </div>

    <p>
        <div class="testo">
        <h4>Cliente</h4>
        <br>
        Ha scelto il profilo cliente!
        <br>
        In questa sezione può effettuare prenotazioni o lasciare recensioni riguardanti i ristoranti registrati.
        <br>
        <br>
        Per effettuare una prenotaione basta <a href="Prenotazione.php">clicchi qui</a>
        <br>
        <br>
        Per lasciare una recensione basta che <a href="Recensione.php">clicchi qui</a>
        <br>
        <br>
        <br>
        <br>
        Per ritornare all'<a href="Ristorante.php">home page</a>
        </div>
    </p>  
    
    </body>

</html>
