<!DOCTYPE html>
<html>

    <head class="col">
        <div class="titolo">
            <h3>RistoClick</h3>
        </div>
        

    </head>
    <body>

        <style>
            .titolo
            {
                align-items: left;
                width: 350px;
                height: 100px;
            }

            body
            {
                background-color:aliceblue;
                font-size: large;
                font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            }
            
            .column1
            {
                color:black;
                font: size 30;
                width: 300px;
                margin-right: 10px;
                float: left;
                margin-top: 0px;
                font-size: 20px;
            }
            h3
            {
                font-family:cursive;
                font-size: 40px;
                color:yellow;
                text-align: center;
                border-style: solid;
                border-radius: 50%;
                border-color: black;
                border-width: 5px;
            }
            h4
            {   
                margin-top: 0px;
                margin-bottom: 5px;
                font-family: fantasy;
                font-size: large;
                font-style: italic;
                font-size: 30px;
            }
            
            .testo
            {
                margin-right: 50px;
                margin-left: 400px;
                margin-top: 40px;
                text-align: justify;
                
            }
                
        </style>


    <hr>
    <div class="column1">
        
        <br>
        <a href="Cliente.php">Cliente</a>
        <ul>
            <li>
                <a href="Prenotazione.php">Prenotazione</a>
            </li>  
            <li>
                <a href="Recensione.php">Recesione</a>
            </li>
        </ul>
        <br>
        <a href="Ristoratore.php">Ristoratore</a>
        <ul>
            <li>
                <a href="Registrazione.php">Registrati</a>
            </li>
            <li>
                <a href="Approvigionamenti.php">Regista approvigionamenti</a>
            </li>
            <li>
                <a href="Magazzini.php">Nuovo magazzino</a>
            </li>
            <li>
                <a href="Personale.php">Aggiungi personale</a>
            </li>
            <li>
                <a href="Rifornitori.php">Aggiungi rifornitore</a>
            </li>
        </ul>
       
    </div>
    <p>
        <div class="testo">
        <h4>Approvigionamenti</h4>
        <br>
        In questa pagina è possibile aggiornare il database con i nuovi acquisti effettuati, riempiendo i campi sottostanti.
        <br>
        <br>
        <small>Se il rifornitore o il magazzino in questione è nuovo o non è mai stato inserito, si prega di registrarlo prima 
            rispettivamente in: <a href="Rifornitori.php">rifornitore</a> o <a href="Magazzini.php">magazzino</a></small>
        <br>
        <br>
        Inserire i dati richiesti:
        <br>
        <br>
        <form action="Approvigionamenti.php" method="POST">
        Nome Ristorante: <input type="text" name="nomeR">
        <br>
        Partita Iva (rifornitore): <input type="text" name="piva">
        <br>
        Codice articolo acquistato: <input type="number" name="codice">
        <br>
        Nome articolo: <input type="text" name="articolo">
        <br>
        Descrizione articolo: <input type="text" name="descriz">
        <br>
        Scadenza: <input type="date" name="scadenza">
        <br>
        Prezzo: <input type="number" name="prezzo">   <small>    *inserire solo il numero</small>
        <br>
        Quantità acquistata: <input type="number" name="quantita">
        <br>
        Codice del magazzino dove verranno riposti: <input type="number" name="id">
        <br>
        <br>
        <input type="submit" value="Salva" name="submit">
        </form>
        <br>
        <br>
        <br>
        Per ritornare all'<a href="Ristorante.php">home page</a>
        </div>
    </p>

    <?php
    //error_reporting(0);

    function Successo()
		{
			echo '<script>
			alert("I dati sono stati inseriti correttamente!")
			</script>';
		}
    
        function Errore()
		{
			echo '<script>
			alert("Errore, i valori inseriti non sono corretti o non sono comleti! Riprova")
			</script>';
		}

    $host = "localhost";
    $database = "ristorante";
    $user = "postgres";
    $password = "12345Ciao6789";

    $connection = pg_connect("host=$host dbname=$database user=$user password=$password") 
        or die(pg_last_error());
	
	$nomeR = $_POST['nomeR'];
	$piva = $_POST['piva'];
    $codice = $_POST['codice'];
    $articolo = $_POST['articolo'];
    $descriz = $_POST['descriz'];
    $scadenza = $_POST['scadenza'];
    $prezzo = $_POST['prezzo'];
    $quantita = $_POST['quantita'];
    $id = $_POST['id'];
    if ((strlen($nomeR) == 0 || $codice <= 0 || $id == 0 || $quantita <= 0 || strlen($piva) == 0 || $prezzo <= 0 || strlen($articolo) == 0) && (strlen($nomeR) != 0 || $codice > 0 || $id != 0 || $quantita > 0 || strlen($piva) != 0 || $prezzo > 0 || strlen($articolo) != 0))
        Errore();
	if(strlen($nomeR) != 0 && $codice > 0 && $id != 0 && $quantita > 0 && strlen($piva) != 0 && $prezzo > 0 && strlen($articolo) != 0)
    {	$query1 = "INSERT INTO prodotto (codice_articolo, nome, descrizione, scadenza) VALUES ($codice, '$articolo', '$descriz', '$scadenza');";
        $query2 = "INSERT INTO contiene (id, nomer, codice_articolo, quantità) VALUES ($id, '$nomeR', $codice, $quantita);";
        $query3 = "INSERT INTO acquistato (nomer, codice_articolo, partita_iva, prezzo, quantità) VALUES ('$nomeR', $codice, '$piva', $prezzo, $quantita);";
        
        
    	$result1 = pg_query($connection, $query1)
        or die();//"Encountered an error when executing given sql statement: ". pg_last_error(). "<br/>");
        $result2 = pg_query($connection, $query2)
        or die();
        $result3 = pg_query($connection, $query3)
        or die();
        if ($result1 != false && $result2 != false && $result3 != false)
            Successo();
    }
    ?>
    
    </body>
        

        <br>

    

</html>
