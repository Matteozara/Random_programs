<!DOCTYPE html>
<html>
    
    <head class="col">
        <div class="titolo">
            <h3>RistoClick</h3>
        </div>
        

    </head>
    <body>

<p>
        In questa pagina è possibile inserire i nuovi rifornitori, o quelli non ancora inseriti, riempiendo i campi sottostanti. 
        <br>
        <br>
        Inserisca un nuovo rifornitore:
        <br>
        <br>
        <form action="Prova.php" method="POST">
        Nome: <input type="text" name="nome">
        <br>
        Partita IVA: <input type="text" name="piva">
        <br>
        Settore in cui opera: <input type="text" name="settore">
        <br>
        Numero: <input type="number" name="numero">
        <br>
        TTT: <input type="text" name="TTT">
        <br>
        <input type="number" name="ultimo">
        <br>
        <input type="submit" value="Inserisci" name="submit">
        </form>

        <br>
        <br>
        <br>
        Per ritornare all'<a href="Ristorante.php">home page</a>

        </div>
    </p>

    <?php
    //error_reporting(0);

    function Successo()
		{
			echo '<script>
			alert("I dati sono stati inseriti correttamente!")
			</script>';
		}
    
        function Errore()
		{
			echo '<script>
			alert("Errore, i valori inseriti non sono corretti o non sono comleti! Riprova")
			</script>';
		}

	$host = "localhost";
    $database = "ristorante";
    $user = "postgres";
    $password = "12345Ciao6789";
    

    $connection = pg_connect("host=$host dbname=$database user=$user password=$password") 
        or die(pg_last_error());
	
	$nome = $_POST['nome'];
	$piva = $_POST['piva'];
    $settore = $_POST['settore'];
    $numero = $_POST['numero'];
	$TTT = $_POST['TTT'];
    $ultimo = $_POST['ultimo'];
    
    //if ((strlen($nome) == 0 || strlen($piva) == 0 || strlen($settore) == 0) && (strlen($nome) != 0 || strlen($piva) != 0 || strlen($settore) != 0))
      //  Errore();
	//if(strlen($nome) != 0 && strlen($piva) != 0 && strlen($settore) != 0)
    {	$query1 = "INSERT INTO Ciao (nomer, città, indirizzo, cap, provincia, posti_disponibili) VALUES ('$nome', '$piva', '$settore', $numero, '$TTT', $ultimo);";
        
    	$result1 = pg_query($connection, $query1)
        or die();//"Encountered an error when executing given sql statement: ". pg_last_error(). "<br/>");
        if ($result1 != false)
            Successo();
    }
    ?>
    </body>
</html>